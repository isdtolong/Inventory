/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package remotedatabasecon;

/**
 *
 * @author artan
 */
public class ServerDetails {
    private String server;
    private String user;
    private String pass;
    
    public void setServer(String pserver){
        this.server = pserver;
    }
    public void setUser(String puser){
        this.user = puser;
    }
    public void setPass(String ppass){
        this.pass = ppass;
    }
    public String getServer(){
        return server;
    }
    public String getUser(){
        return user;
    }
    public String getPass(){
        return pass;
    }
}

