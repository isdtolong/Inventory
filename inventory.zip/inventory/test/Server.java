/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author artan
 */
public class Server extends UnicastRemoteObject implements jdbcguiInterface{
    
    public Server() throws RemoteException{
        super();
    }
    public static void main(String[] args) throws RemoteException{
        Registry reg=LocateRegistry.createRegistry(1099);
        Server s=new Server();
        reg.rebind("db", s);
        System.out.println("Server is running now....");
    }    
    @Override
    public String Delete(int id) throws RemoteException {
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/rmiTest","root","");
            Statement st=con.createStatement();
            String sql="delete from student where id='"+id+"'";
            st.executeUpdate(sql);
            return "Record Deleted Successfully";
            }
        catch(Exception e)
        {
            return (e.toString());
        }
    }
    @Override
    public String Update(String name, int id, String gender, int age, String dept, String year) throws RemoteException {
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/rmiTest","root","");
            Statement st=con.createStatement();
            String sql="update student set name='"+name+"',gender='"+gender+"',dept='"+dept+"',age='"+age+"',year='"+year+"' where id='"+id+"'";
            
            st.executeUpdate(sql);
            return "Record Updated Successfully";
            }
        catch(Exception e)
        {
            return (e.toString());
        }
    }

    @Override
    public ArrayList Search(int id) throws RemoteException {
   
        ArrayList student=new ArrayList();
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/rmiTest","root","");
            Statement st=con.createStatement();
            String sql="select * from student where id='"+id+"'";
            ResultSet rs;
            rs=st.executeQuery(sql);
            while(rs.next()){
                student.add("Name:"+rs.getString("name"));
                student.add("Gender:"+rs.getString("gender"));
                student.add("Dept:"+rs.getString("dept"));
                student.add("Age:"+rs.getString("age"));
                student.add("Year:"+rs.getString("year"));
                
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return student;
        }

    @Override
    public String Insert(String name, int id, String gender, int age, String dept, String year) throws RemoteException {
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/rmiTest","root","");
            Statement st=con.createStatement();
            String sql="insert into student values('"+id+"','"+name+"','"+gender+"','"+dept+"','"+age+"','"+year+"' )";
            
            st.executeUpdate(sql);
            return "Record Inserted Successfully";
            }
        catch(Exception e)
        {
            return (e.toString());
        }
    }

}
