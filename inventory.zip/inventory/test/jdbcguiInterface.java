/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import RMIserverconfig.*;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;
/**
 *
 * @author artan
 */
public interface jdbcguiInterface extends Remote{
    
    public String Delete(int id) throws RemoteException;
    
    public String Insert(String name, int id, String gender, int age, String dept, String year) throws RemoteException;
    
    public String Update(String name, int id, String gender, int age, String dept, String year) throws RemoteException;
    
    public ArrayList Search(int id) throws RemoteException;
    
}
